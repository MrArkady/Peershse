using System;
using System.Collections.Generic;
using System.IO;

namespace MatrixCalc
{
    public class Screen
    {
        
        
        
        public static void OutputHelp()
        {
            string help = File.ReadAllText("help.txt");
            Console.WriteLine(help);
        }

        public static void CleanScreen()
        {
            Console.Clear();
        }
        
        /// <summary>
        /// Prints Message with type color  
        /// </summary>
        /// <param name="message">Dirctionary of message and type possible
        /// types - exception, folder, file</param>
        /// <exception cref="Exception">If Type is wrong</exception>
        public static void OutputMessage(Dictionary<string, string> message)
        {
            foreach (var i in message)
            {
                switch (i.Value)
                {
                    // Output Color = RED
                    case "exception":
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine(i.Key);
                        Console.ResetColor();
                        break;
                    // Output Color = Green
                    case "fraction":
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(i.Key);
                        Console.ResetColor();
                        break;
                    // Output Color = Blue
                    case "file":
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.WriteLine(i.Key);
                        Console.ResetColor();
                        break;
                    default:
                        throw new Exception("Wrong Type When Output");
                }
            }
        }

    }
}