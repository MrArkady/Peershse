namespace MatrixCalc
{
    public static class Input
    {
        public static string GetFractionType(string inputNumber)
        {
            if (int.TryParse(inputNumber, out var numberInt))
                return "int";
            if (double.TryParse(inputNumber, out var numberDouble))
                return "double";
            var inputSplit
            if (inputNumber.Split('/').Length == 2 && 
                )
            return 

        }
    }
}