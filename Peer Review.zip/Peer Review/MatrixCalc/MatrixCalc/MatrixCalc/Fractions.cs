using System;
using System.Collections.Generic;
using System.Globalization;
using System.Runtime.CompilerServices;

namespace MatrixCalc
{
    public class Fractions
    {
        public Tuple<double, double> _fraction;
        public string error;

        public Fractions(string inputNumber)
        {
            this.error = ParseInput(inputNumber);
            if (this.error != "ok")
            {
                ThrowException(this.error);
            }
            this.Optimise();
        }

        public override string ToString()
        {
            try
            {
                this.Optimise();
                
                var res = _fraction.Item2 == 1?
                    _fraction.Item1.ToString(CultureInfo.InvariantCulture)
                    :string.Join("", _fraction.Item1, "/", _fraction.Item2);
                return res;
            }
            catch (Exception e)
            {
                ThrowException(e.Message);
                return "";
            }
        }

        private void ThrowException(string message)
        {
            var mess = new Dictionary<string, string>() {{message, "exception"}};
            Screen.OutputMessage(mess);
        }

        private string ParseInput(string inputNumber)
        {
            if (int.TryParse(inputNumber, out var numberInt))
                return ParseInt(numberInt);

            if (double.TryParse(inputNumber, out var numberDouble))
                return ParseDouble(inputNumber, numberDouble);

            if (inputNumber.Split('/').Length == 2)
                return ParseFraction(inputNumber.Split('/')[0],
                    inputNumber.Split('/')[1]);
            return "wrong";
        }

        private string ParseFraction(string aStr, string bStr)
        {
            int a, b;
            if (!(int.TryParse(aStr, out a) &
                  int.TryParse(bStr, out b)))
            {
                return "wrong fraction parts";
            }

            try
            {
                this._fraction = new Tuple<double, double>((double) a, (double) b);
            }
            catch (Exception e)
            {
                return e.Message;
            }

            return "ok";
        }

        private string ParseDouble(string inputNumber, double numberDouble)
        {
            try
            {
                var strNumber = inputNumber.Split(new char[] {'.', ','});
                if (strNumber.Length != 2)
                    return "wrong type";
                var power = Math.Pow(10, strNumber[1].Length);
                this._fraction = new Tuple<double, double>(numberDouble * power, power);
            }
            catch (Exception e)
            {
                return e.Message;
            }

            return "ok";
        }

        private string ParseInt(int numberInt)
        {
            try
            {
                this._fraction = new Tuple<double, double>((double) numberInt, (double) 1);
            }
            catch (Exception e)
            {
                return e.Message;
            }

            return "ok";
        }

        private void Optimise()
        {
            var gcf = MathExtention.Gcf(this._fraction.Item1, this._fraction.Item2);
            var resNumerator = this._fraction.Item1 / gcf;
            var resDenominator = this._fraction.Item2 / gcf;
            resNumerator *= Math.Sign(resDenominator);
            resDenominator *= Math.Sign(resDenominator);
            var newFraction = new Tuple<double, double>(resNumerator, resDenominator);
            this._fraction = newFraction;
        }

        public static Fractions operator +(Fractions a) => a;

        public static Fractions operator -(Fractions a) => new Fractions(String.Join("",
            a._fraction.Item1 * (-1), "/", a._fraction.Item2));

        public static Fractions operator +(Fractions a, Fractions b)
        {
            double resNumerator, resDenominator;
            resNumerator = a._fraction.Item1 * b._fraction.Item2 + a._fraction.Item2 * b._fraction.Item1;
            resDenominator = a._fraction.Item2 * b._fraction.Item2;
            var resStr = string.Join("", resNumerator, "/", resDenominator);
            var res = new Fractions(resStr);
            res.Optimise();
            return res;
        }

        public static Fractions operator -(Fractions a, Fractions b)
        {
            return a + (-b);
        }

        public static Fractions operator *(Fractions a, Fractions b)
        {
            var resNumerator = a._fraction.Item1 * b._fraction.Item1;
            var resDenominator = a._fraction.Item2 * b._fraction.Item2;
            var resStr = string.Join("", resNumerator, "/", resDenominator);
            var res = new Fractions(resStr);
            res.Optimise();
            return res;
        }
        
        public static Fractions operator /(Fractions a, Fractions b)
        {
            var resNumerator = b._fraction.Item2;
            var resDenominator = b._fraction.Item1;
            var resStr = string.Join("", resNumerator, "/", resDenominator);
            var res = new Fractions(resStr);
            res.Optimise();
            return a * res;
        }
    }
}