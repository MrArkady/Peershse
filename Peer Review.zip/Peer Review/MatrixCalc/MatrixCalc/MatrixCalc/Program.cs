﻿using System;

namespace MatrixCalc
{
    class Program
    {
        static void Main()
        {
            var matrix = new Matrix(2,2);
            matrix.InputMatrix();
            Console.WriteLine(matrix);
            Console.WriteLine(matrix.Determinant());
        }
    }
}