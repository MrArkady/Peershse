using System;
using System.Collections.Generic;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Xml;

namespace MatrixCalc
{
    public class Matrix
    {
        private Tuple<int, int> dimension;
        private Fractions[,] matrix;
        private string matrixType;
        
        public Fractions GetElement(int i, int j) => this.matrix[i,j];

        public void SetElement(int i, int j, Fractions element) => this.matrix[i, j] = element; 
        public Matrix(int n, int m)
        {
            if (n == 0 | m == 0)
            {
                this.matrixType = "wrong";
                ThrowException("0 Exception");
            }
            if (n == m)
                matrixType = "square";
            else
                matrixType = "none";
            this.dimension = new Tuple<int, int>(n,m);
            this.matrix = new Fractions[this.dimension.Item1,this.dimension.Item2];
        }
        
        private void ThrowException(string message)
        {
            var mess = new Dictionary<string, string>() {{message, "exception"}};
            Screen.OutputMessage(mess);
        }

        static bool Safe_input(out Fractions firstDigit)
        {
            firstDigit = new Fractions(Console.ReadLine());
            if (firstDigit.error != "ok")
            {
                return false;
            }
            return true;
        }
        
        public bool InputMatrix()
        {
            for (int i = 0; i < this.dimension.Item1; i++)
            {
                for (int j = 0; j < this.dimension.Item2; j++)
                {
                    if (!Safe_input(out this.matrix[i, j]))
                    {
                        this.ThrowException("Try Again");
                        return false;
                    }
                    
                }
            }
            return true;
        }

        public override string ToString()
        {
            try
            {
                var resFormat = "";
                for (int i = 0; i < this.dimension.Item1; i++)
                {
                    for (int j = 0; j < this.dimension.Item2; j++)
                    {
                        resFormat += "\t" + this.matrix[i, j] + "\t";
                    }
                    resFormat += "\n";
                }
                return resFormat;
            }
            catch (Exception e)
            {
                ThrowException("Wrong While Output");
                return "";
            }
        }

        private Matrix CreateMatrixWithoutColumn(int column)
        {
            var newMatrix = new Matrix(this.dimension.Item1, this.dimension.Item2 - 1);
            if (!(column >= this.dimension.Item2 | column <= 0))
            {
                for (int i = 0; i < this.dimension.Item1; i++)
                {
                    for (int j = 0; j < this.dimension.Item2; j++)
                    {
                        if (j != column)
                            newMatrix.SetElement(i,j, this.GetElement(i,j));
                    }
                }
            }
            return newMatrix;
        }
        private Matrix CreateMatrixWithoutString(int str)
        {
            var newMatrix = new Matrix(this.dimension.Item1 - 1, this.dimension.Item2);
            if (!(str >= this.dimension.Item1 | str <= 0))
            {
                for (int i = 0; i < this.dimension.Item1; i++)
                {
                    for (int j = 0; j < this.dimension.Item2; j++)
                    {
                        if (i != str)
                            newMatrix.SetElement(i,j, this.GetElement(i,j));
                    }
                }
            }
            return newMatrix;
        }
        public Fractions Determinant()
        {
            var determinant = new Fractions("0");
            if (this.matrixType == "square")
            {
                var newMatrix = this.CreateMatrixWithoutString(1);
                if (this.dimension.Item1 == 1)
                {
                    return this.matrix[0, 0];
                }
                for (int i = 0; i < this.dimension.Item2; i++)
                {
                    var sgn = new Fractions(Math.Pow(-1, i).ToString(CultureInfo.InvariantCulture));
                    determinant += sgn * this.matrix[0, i] * newMatrix.CreateMatrixWithoutColumn(i).Determinant();
                }
            }
            return determinant;
        }
    
    
    }
}