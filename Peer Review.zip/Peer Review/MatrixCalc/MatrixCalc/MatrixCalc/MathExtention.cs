using System;

namespace MatrixCalc
{
    public class MathExtention
    {
        public static double Gcf(double a, double b)
        {
            while (b != 0)
            {
                double temp = b;
                b = a % b;
                a = temp;
            }
            return a;
        }
        public static double Lcm(int a, int b)
        {
            return (a / Gcf(a, b)) * b;
        }

    }
}