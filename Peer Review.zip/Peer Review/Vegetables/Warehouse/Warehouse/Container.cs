using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;

namespace Warehouse
{
    public class Container
    {
        // Personal Container ID
        private readonly int _containerId;
        // List of boxes contained in this container
        private readonly List<Box> _boxes = new List<Box>();
        private readonly double _maxWeight;
        private readonly double _damageDegree;
        
        // Returns the current weight of the box
        private double NowWeight => _boxes.ConvertAll(x => x.Weight).Sum();
        // Returns the cost reduced depending on the damage
        public double СostLostWithDamage => _boxes.Sum(x => x.Cost) * this._damageDegree;
        
        // Returns the cost
        private double Cost => _boxes.Sum(box => box.Cost);
        public int GetId() => this._containerId; 

        /// <summary>
        /// Container constructor
        /// </summary>
        public Container()
        {
            this._damageDegree = new Random().NextDouble(0,0.6);
            this._maxWeight = new Random().NextDouble()*950 + 50;
            _containerId = VirtualWarehouse.AddNewContainerToVirtualWarehouse(this);
        }
        
        /// <summary>
        /// Adding a box to a container
        /// </summary>
        /// <remarks>If the weight of the container after adding a new box
        /// exceeds the maximum weight of the container, then the box is not added</remarks>
        /// <remarks>If the box is already present in the container, then it is not added to it</remarks>
        /// <remarks>If the box is not in the Virtual Storage, then it is not added</remarks>
        /// <param name="box"></param>
        /// <returns>Done or not</returns>
        public bool AddBoxToContainer(Box box)
        {
            if (!(this._maxWeight >= this.NowWeight + box.Weight)) return false;
            if(!VirtualWarehouse.RemoveBoxFromVirtualWarehouse(box)) return false;
            if (_boxes.Contains(box))
            {
                return false;
            }
            _boxes.Add(box);
            return true;
        }
        
        /// <summary>
        /// Removes a box from a container if there is one
        /// </summary>
        /// <param name="box">The class object the box to be deleted</param>
        /// <returns>Done or not</returns>
        public bool RemoveBoxFromContainer(Box box)
        {
            if (!_boxes.Contains(box)) return false;
            _boxes.Remove(box);
            VirtualWarehouse.AddBoxToVirtualWarehouse(box);
            return true;
        }
        /// <summary>
        /// looking for a box in a container by id
        /// </summary>
        /// <param name="id" type="int">Box id</param>
        /// <returns>Returns an object of class box by id</returns>
        public Box FindBox(int id)
        {
            return _boxes.Find(x => x.GetId() == id);
        }
        
        /// <summary>
        /// Generating a line with information about a Container
        /// </summary>
        /// <returns>string with information</returns>
        public override string ToString()
        {
            var res = $"|\tid: {this._containerId}\t|\tMax: {this._maxWeight}\t|" +
                      $"\tNow: {this.NowWeight}\t|\tCost: {this.Cost}\t|\tCostWihDamage: {this.СostLostWithDamage}\n";
            foreach (var box in this._boxes)
            {
                res += "\t" + box + Environment.NewLine;
            }

            return res;
        }
    }
}