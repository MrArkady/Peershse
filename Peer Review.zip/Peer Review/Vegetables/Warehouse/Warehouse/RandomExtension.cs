using System;

namespace Warehouse
{
    public static class RandomExtension
    {
        /// <summary>Returns a random double number in the given rangeе</summary>
        /// <param name="random">Random instance</param>
        /// <param name="minValue">Range start</param>
        /// <param name="maxValue">End of range</param>
        /// <returns></returns>
        public static double NextDouble(this Random random, double minValue = double.MinValue, double maxValue = double.MaxValue)
            => random.NextDouble() * (maxValue - minValue) + minValue;
    }
}