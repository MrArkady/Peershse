using System;
using System.Collections.Generic;
using System.Threading.Channels;

namespace Warehouse
{
    /// <summary>
    /// This class provides display of information to the user on the Screen
    /// </summary>
    public static class Screen
    {
        
        /// <summary>
        /// Displaying an information message for the user
        /// </summary>
        /// <param name="messages">Dictionary (Message, Message Type)
        /// The message type can be:
        /// Error
        /// Message
        /// </param>
        public static void PrintMessage(Dictionary<string, string> messages)
        {
            foreach (var message in messages)
            {
                switch (message.Value)
                {
                    case "Error":
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine(message.Key);
                        Console.ResetColor();
                        break;
                    case "Message":
                        Console.ForegroundColor = ConsoleColor.Blue;
                        Console.WriteLine(message.Key);
                        Console.ResetColor();
                        break;
                    case "Else":
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(message.Key);
                        Console.ResetColor();
                        break;
                    case "InfoAbout":
                        Console.ForegroundColor = ConsoleColor.Magenta;
                        Console.WriteLine(message.Key);
                        Console.ResetColor();
                        break;
                    default:
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Wrong Type of message");
                        Console.ResetColor();
                        break;
                }
            }
        }

        /// <summary>
        /// Displays starting information for the user: greeting, rules
        /// </summary>
        public static void PrintFileInfo()
        {
            Console.Clear();
            var rules = "ПРО РЕЖИМ ВЗАИМОДЕЙСТВИЯ ЧЕРЕЗ ФАЙЛЫ\n" +
                        "Правила:\n" +
                        "\t1. В папке проекта должны лежать 3 файла(/Warehouse/bin/Debug/netcoreapp3.1)\n" +
                        "\t\t1.1 WareHouse.txt\n" +
                        "\t\t1.2 Containers.txt\n" +
                        "\t\t1.3 Actions.txt\n" +
                        "\n\n\n" +
                        "\tФАЙЛ WareHouse.txt содержит информацию о Складе\n" +
                        "\t\t1-ая строка - число помещающихся контейнеров\n" +
                        "\t\t2-ая строка - Стоимость хранения одного контейнера\n" +
                        "\n\n\n" +
                        "\tФАЙЛ Containers.txt содержит информацию обо всех контейнерах\n" +
                        "\t\tКаждый контейнер описывается по следующим правилам\n" +
                        "\t\tОбъявление нового контейнера - Container<x>, где х - число коробок внутри\n" +
                        "\t\tДалее х строчек формата цена|вес\n" +
                        "\n\n\n" +
                        "\tФАЙЛ Actions.txt содержит информацию обо всех действиях\n" +
                        "\t\tДоступны команды по 3-ех видов\n" +
                        "\t\t\tAddContainer - добавляет следующий контейннер из файла на склад(если возможно)\n" +
                        "\t\t\tLookAround - Выводит информацию о складе и его содержимом\n" +
                        "\t\t\tRemoveContainer<х> - удаляет со склада контейнер под номером х\n";
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine(rules);
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Если всё готово - нажми любую кнопку");
            Console.ReadLine();
            Console.ResetColor();
            Console.Clear();
        }

        /// <summary>
        /// Displays starting information for the user: greeting, rules
        /// </summary>
        public static void PrintConsoleInfo()
        {
            Console.Clear();
            var rules = "Ты находишься на складе №1\n" +
                        "У тебя есть возможность\n" +
                        "\t1. Создать новую коробку\n" +
                        "\t2. Создать контейнер\n"+
                        "\t\t2.1 Создать пустой контейнер\n"+
                        "\t\t2.2 Создать пустой контейнер и сразу же добавить в него коробки(создать новые)"+
                        "\t3. Поместить контейнер на склад"+
                        "\t4. Убрать контейнер со склада"+
                        "\t5. Просмотреть список коробок не помещенных в контейнер"+
                        "\t6. Просмотреть список контейнеров не помещенных на склад"+
                        "\t7. Положить в контейнер коробку  // не показываются ошибки"+
                        "\t8. Убрать из контейнера коробку"+
                        "\t9. Посмотреть информацию о складе"+
                        "\t10. Посмотреть информацию о контейнере"+
                        "\t11. Посмотреть информацию о коробке"+
                        "\t0. Выйти из программы";
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine(rules);
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Если ты готов - нажми любую кнопку");
            Console.ResetColor();
            Console.ReadLine();
            Console.Clear();
        }
        
        /// <summary>
        /// Displays starting information for the user: greeting, rules
        /// </summary>
        public static void PrintStartInfo()
        {
            var first = "Давай ознакомлю тебя с тем, что ты можешь \n" +
                        "Советую тебе внимательно прочитать данную инструкцию!\n" +
                        "Для начала тебе предложат Выбрать способ взаимодействия с программой\n" +
                        "\t1. Взаимодействие при помощи консоли\n" +
                        "\t2. Взаимодействие при помощи файлов с инструкциями\n" +
                        "ПОМНИ - ПОНЛЫЙ ФУНКЦИОНАЛ ДОСТУПЕН ТОЛЬКО В РЕЖИМЕ ВЗАИМОДЕЙСТВИЯ ЧЕРЕЗ КОНСОЛЬ\n" +
                        "Сменить способ нельзя взаимодействия нельзя\n" +
                        "После этого я выведу тебе информацию о каждом из способов(в зависимости от выбранного)\n";
            
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("ПРИВЕТСТВУЮ В СИМУЛЯТОРЕ СКЛАДЁРА");
            Console.WriteLine("Если готов начинать - нажми любую клавишу");
            Console.ReadLine();
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine(first);
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("ВВОДИ");
            Console.ResetColor();
        }
        
        /// <summary>
        /// Lists boxes
        /// </summary>
        /// <param name="boxes">List of boxes</param>
        public static void PrintBoxArray(List<Box> boxes)
        {
            Console.WriteLine("ЯЩИКИ: \n");
            foreach (var box in boxes)
            {
                Console.WriteLine(box);
            }

            Console.WriteLine("_______________________________");
        }

        /// <summary>
        /// Lists Containers
        /// </summary>
        /// <param name="containers">List of containers</param>
        public static void PrintContainerArray(List<Container> containers)
        {
            Console.WriteLine("КОНТЕЙНЕРЫ: \n");
            foreach (var container in containers)
            {
                Console.WriteLine(container);
            }
            Console.WriteLine("_______________________________");
        }
    }
}