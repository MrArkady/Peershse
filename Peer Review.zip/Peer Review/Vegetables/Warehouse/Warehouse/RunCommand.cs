using System;
using System.Collections.Generic;

namespace Warehouse
{
    public static class RunCommand
    {
        public static Warehouse Warehouse;
        
        /// <summary>
        /// Creates a new warehouse
        /// </summary>
        /// <param name="maxCount">Capacity</param>
        /// <param name="cost">Price per Container</param>
        /// <returns></returns>
        public static Warehouse CreateWarehouse(int maxCount, double cost)
        {
            try
            {
                var warehouse = new Warehouse(maxCount, cost);
                return warehouse;
            }
            catch (Exception e)
            {
                return null;
            }
        }
        
        /// <summary>
        /// Displays information about the warehouse
        /// </summary>
        /// <returns type="string">information about the warehouse</returns>
        public static string LookForWarehose()
        {
            return Warehouse.ToString();
        }
        
        /// <summary>
        /// Add Container To Warehouse by id
        /// </summary>
        /// <param name="idCont">Container id</param>
        /// <returns>Done or not</returns>
        public static bool AddContainerToWarehouse(int idCont)
        {
            try
            {
                var newCont = VirtualWarehouse.FindContainer(idCont);
                if (newCont == null) return false;
                Warehouse.AddToWarehouse(newCont);
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }
        
        /// <summary>
        /// Create New Box and add it to VirtualWarehouse
        /// </summary>
        /// <param name="price">Price</param>
        /// <param name="weight">Weight</param>
        /// <returns>Box</returns>
        public static Box CreateNewBox(double price, double weight)
        {
            try
            {
                var newBox = new Box(price, weight);
                return newBox;
            }
            catch (Exception e)
            {
                return null;
            }
        }
        
        /// <summary>
        /// Create New Container and add it to VirtualWarehouse
        /// </summary>
        /// <returns>Container</returns>
        public static Container CreateEmptyContainer()
        {
            
            return new Container();
        }

        /// <summary>
        /// Add Box To Container by id
        /// </summary>
        /// <param name="idBox">Box id</param>
        /// <param name="idCont">Container id</param>
        /// <returns>Done or not</returns>
        public static bool AddBoxToContainer(int idBox, int idCont)
        {
            var cont = VirtualWarehouse.FindContainer(idCont);
            var box = VirtualWarehouse.FindBox(idBox);
            if (box == null)
            {
                return false;
            }
            if (cont == null)
            {
                return false;
            }
            cont.AddBoxToContainer(box);
            return true;
        }
        
        /// <summary>
        /// Remove Container From Warehouse
        /// </summary>
        /// <param name="idCont">Container id</param>
        /// <returns>Done or not</returns>
        public static bool RemoveContainerFromWarehouse(int idCont)
        {
            var cont = Warehouse.FindContainer(idCont);
            if (cont == null)
            {
                return false;
            }
            Warehouse.RemoveContainerFromWarehouse(cont);
            return true;
        }

        /// <summary>
        /// Displays information about the container
        /// </summary>
        /// <param name="idCont">Container id</param>
        /// <returns type="string">information about the container</returns>
        public static string LookForContainer(int idCont)
        {
            var cont = VirtualWarehouse.FindContainer(idCont) ?? Warehouse.FindContainer(idCont);
            return cont == null ? "wrong Container" : cont.ToString();
        }

        /// <summary>
        /// Displays information about the box
        /// </summary>
        /// <param name="idBox">Box id</param>
        /// <returns type="string">information about the box</returns>
        public static string LookForBox(int idBox)
        {
            var box = VirtualWarehouse.FindBox(idBox) ?? Warehouse.FindBoxInContainers(idBox);
            return box == null ? "No such Box" : box.ToString();
        }
        
        /// <summary>
        /// List of all boxes in Virtual Warehouse
        /// </summary>
        /// <returns>List of all boxes in Virtual Warehouse</returns>
        public static List<Box> LookForBoxesInVirtualWarehouse()
        {
            return VirtualWarehouse._boxes;
        }
        
        /// <summary>
        /// List of all containers in Virtual Warehouse
        /// </summary>
        /// <returns>List of all containers in Virtual Warehouse</returns>
        public static List<Container> LookForContainersInVirtualWarehouse()
        {
            return VirtualWarehouse._containers;
        }

        /// <summary>
        /// Remove Box From Container by id
        /// </summary>
        /// <param name="idBox">Box id</param>
        /// <param name="idCont">Container id</param>
        /// <returns>Done or not</returns>
        public static bool RemoveBoxFromContainer(int idBox, int idCont)
        { 
            var cont = VirtualWarehouse.FindContainer(idCont) ?? Warehouse.FindContainer(idCont);
            var box = cont?.FindBox(idBox);
            if (box == null)
            {
                return false;
            }
            cont.RemoveBoxFromContainer(box);
            return true;
        }
    }
}
