﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Warehouse
{
    internal static class Program
    {
        /// <summary>
        /// Runs a program to work with the console
        /// </summary>
        private static void RunWithConsole()
        {
            try
            {
                Screen.PrintConsoleInfo();
                if (ConsoleInputParse.CreateWarehouse() != true) return;
                while (ConsoleInputParse.AskForCommand())
                {
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw;
            }
        }
        /// <summary>
        /// Launches a program for working with files
        /// </summary>
        private static void RunWithFiles()
        {
            try
            {
                Screen.PrintFileInfo();
                if(!FileInputParse.ReadWarehouseFile())
                    Console.WriteLine("FuckYou");
                if (!FileInputParse.ReadContainersFile())
                    Console.WriteLine("FUCK YOU 2");
                if(!FileInputParse.ReadActionsFile())
                    Console.WriteLine("FUCK YOU 3 blyat");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        private static void Main(string[] args)
        {
            // Displays predictive information
            Screen.PrintStartInfo();
            // Checks the correctness of the choice of interaction with the program
            var correctVariant = false;
            
            //Calls the function according to the selection
            while (!correctVariant)
            {
                switch (Console.ReadLine())
                {
                    case "1":
                        correctVariant = true;
                        RunWithConsole();
                        break;
                    case "2":
                        correctVariant = true;
                        RunWithFiles();
                        break;
                    default:
                        Console.WriteLine("Try Again");
                        break;
                }    
            }
            
        }
        
    }
}