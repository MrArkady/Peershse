using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

namespace Warehouse
{
    public static class FileInputParse
    {
        /// <summary>
        /// Displaying an error message
        /// </summary>
        /// <param name="message">Message line</param>
        private static void DropPanic(string message)
        {
            Screen.PrintMessage(new Dictionary<string, string>() {{message, "Error"}});
        }
        /// <summary>
        /// Reads information about a warehouse from a file
        /// </summary>
        /// <returns>Done or not</returns>
        public static bool ReadWarehouseFile()
        {
            try
            {
                var warehouseInfo = File.ReadAllText("WareHouse.txt").
                    Split(new []{'\n'}).ToList().ConvertAll(x => int.Parse(x));
                RunCommand.Warehouse = RunCommand.CreateWarehouse(warehouseInfo[0], warehouseInfo[1]);
                return RunCommand.Warehouse != null;
            }
            catch (Exception e)
            {
                DropPanic(e.Message);
                return false;
            }
        }

        /// <summary>
        /// Reads information about all containers from a file, creates them and adds them to
        /// </summary>
        /// <returns>Done or not</returns>
        public static bool ReadContainersFile()
        {
            try
            {
                var rx = new Regex("Container<.*>");
                using var sr = new StreamReader("Containers.txt");
                while (!sr.EndOfStream)
                {
                    var newLine = sr.ReadLine();
                    if (!rx.IsMatch(newLine ?? "")) continue;
                    var newCont = new Container();
                    var countStr = new Regex("<.*>").Match(newLine ?? "").Value;
                    var count = int.Parse(countStr.Substring(1, countStr.Length-2));
                    for (var i = 0; i < count; i++)
                    {
                        var data = sr.ReadLine()?.Split(new[] {'|'}).ToList().
                            ConvertAll(double.Parse);
                        if (data == null) return false;
                        var newBox = RunCommand.CreateNewBox(data[0], data[1]);
                        newCont.AddBoxToContainer(newBox);
                    }
                }

                return true;
            }
            catch (Exception e)
            {
                DropPanic(e.Message);
                Console.WriteLine(e);
                return false;
            }
        }

        /// <summary>
        /// Reads actions from a file and executes them
        /// </summary>
        /// <returns>Done or not</returns>
        public static bool ReadActionsFile()
        {
            var add = new Regex("AddContainer");
            var show = new Regex("LookAround");
            var remove = new Regex("RemoveContainer<.*>");
            try
            {
                using var sr = new StreamReader("Actions.txt");
                while (!sr.EndOfStream)
                {
                    var newLine = sr.ReadLine();
                    if (add.IsMatch(newLine ?? ""))
                        RunCommand.AddContainerToWarehouse(VirtualWarehouse.FirstContainer.GetId());
                    else if (show.IsMatch(newLine ?? ""))
                        Screen.PrintMessage(new Dictionary<string, string>()
                        {
                            {RunCommand.LookForWarehose(),"InfoAbout"}
                        });
                    else if (remove.IsMatch(newLine ?? ""))
                    {
                        var idStr = new Regex("<.*>").Match(newLine ?? "").Value;
                        var id = int.Parse(idStr.Substring(1, idStr.Length-2));
                        RunCommand.RemoveContainerFromWarehouse(id);
                    }
                    else
                        Console.WriteLine(newLine);
                }
            }
            catch (Exception e)
            {
                DropPanic(e.Message);
                return false;
            }
            return true;
        }
    }
}