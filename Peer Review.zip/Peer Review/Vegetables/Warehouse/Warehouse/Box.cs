namespace Warehouse
{
    /// <summary>
    /// The class that implements the box
    /// </summary>
    public class Box
    {
        // Personal box ID
        private readonly int _boxId;
        private readonly double _price;
        // Counting Cost of the Box
        public double Cost => this.Weight * this._price;
        public double Weight { get; }
        public int GetId() => _boxId;
        

        /// <summary>
        /// Constructor for a box without specifying the accessory to the container
        /// </summary>
        /// <param name="price">Price of the box</param>
        /// <param name="weight">Weight of the box</param>
        public Box(double price, double weight)
        {
            this._price = price;
            this.Weight = weight;
            this._boxId = VirtualWarehouse.AddNewBoxToVirtualWarehouse(this);
        }
        /// <summary>
        /// Constructor for the box, indicating the accessories to the container
        /// </summary>
        /// <param name="price">Price of the box</param>
        /// <param name="weight">Weight of the box</param>
        /// <param name="container">A container class object to which the box
        /// should be attached (if possible)</param>
        public Box(double price, double weight, Container container)
        {
            this._price = price;
            this.Weight = weight;
            if (!container.AddBoxToContainer(this))
                this._boxId = VirtualWarehouse.AddNewBoxToVirtualWarehouse(this);
        }
        
        /// <summary>
        /// Generating a line with information about a box
        /// </summary>
        /// <returns>string with information</returns>
        public override string ToString()
        {
            var res = $"{this._boxId}\t{this.Weight}\t{this.Cost}";
            return res;
        }
    }
}