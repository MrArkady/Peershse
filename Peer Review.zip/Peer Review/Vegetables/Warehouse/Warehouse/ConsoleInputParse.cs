using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;

namespace Warehouse
{
    /// <summary>
    /// A class that implements user interaction
    /// </summary>
    public static class ConsoleInputParse
    {
        public static Warehouse Warehouse;

        public static bool CreateWarehouse()
        {
            Screen.PrintMessage(new Dictionary<string, string>() {{"Введи Размер склада", "Message"}});
            if (!int.TryParse(Console.ReadLine(), out var maxCount) || maxCount <= 0)
            {
                DropPanic("Неверный ввод");
                return false;
            }
            Screen.PrintMessage(new Dictionary<string, string>() {{"Введи Стоимость содержания", "Message"}});
            if (!double.TryParse(Console.ReadLine(), out var cost) || cost <= 0)
            {
                DropPanic("Неверный ввод");
                return false;
            }
            
            RunCommand.Warehouse = RunCommand.CreateWarehouse(maxCount, cost);
            
            return RunCommand.Warehouse != null;
        }
        /// <summary>
        /// List of user options at the first access level
        /// </summary>
        private static readonly Dictionary<string, string> PossibleCommandsSimular =
            new Dictionary<string, string>() {
                {"1. Создать новую коробку", "Else"},
                {"2. Создать контейнер", "Else"},
                {"3. Поместить контейнер на склад", "Else"},
                {"4. Убрать контейнер со склада", "Else"},
                {"5. Просмотреть список коробок не помещенных в контейнер", "Else"},
                {"6. Просмотреть список контейнеров не помещенных на склад", "Else"},
                {"7. Положить в контейнер коробку", "Else"},
                {"8. Убрать из контейнера коробку", "Else"},
                {"9. Посмотреть информацию о складе", "Else"},
                {"10. Посмотреть информацию о контейнере", "Else"},
                {"11. Посмотреть информацию о коробке", "Else"},
                {"0. Выйти из программы", "Else"},
            };

        /// <summary>
        /// Asks the user for the number of the command being executed
        /// </summary>
        /// <returns>Continue working with the program or not</returns>
        public static bool AskForCommand()
        {
            Screen.PrintMessage(PossibleCommandsSimular);
            switch (Console.ReadLine())
            {
                case "0":
                    DropPanic("Have a nice day");
                    return false;
                case "1":
                    CreateNewBox();
                    return true;
                case "2":
                    CreateNewContainer();
                    return true;
                case "3":
                    AddContainerToWarehouse();
                    return true;
                case "4":
                    RemoveContainerFromWarehouse();
                    return true;
                case "5":
                    LookForBoxesInVirtualWarehouse();
                    return true;
                case "6":
                    LookForContainersInVirtualWarehouse();
                    return true;
                case "7":
                    AddBoxToContainer();
                    return true;
                case "8":
                    RemoveBoxFromContainer();
                    return true;
                case "9":
                    LookForWarehose();
                    return true;
                case "10":
                    LookForContainer();
                    return true;
                case "11":
                    LookForBox();
                    return true;
                default:
                    DropPanic("Неверный выбор");
                    return true;
            }
        }
        
        /// <summary>
        /// Displaying an error message
        /// </summary>
        /// <param name="message">Message line</param>
        private static void DropPanic(string message)
        {
            Screen.PrintMessage(new Dictionary<string, string>() {{message, "Error"}});
        }
        
        /// <summary>
        /// Displaying information about the warehouse and all its contents
        /// </summary>
        /// <returns>correct or not</returns>
        private static bool LookForWarehose()
        {
            Screen.PrintMessage(new Dictionary<string, string>()
            {
                {RunCommand.LookForWarehose(), "InfoAbout"}
            });
            return true;
        }
        
        /// <summary>
        /// Reads the ID and adds a container to the warehouse using it
        /// </summary>
        /// <returns></returns>
        private static bool AddContainerToWarehouse()
        {
            Screen.PrintMessage(new Dictionary<string, string>() {{"Введи ID Контейнера", "Message"}});
            if (!int.TryParse(Console.ReadLine(), out var idCont))
            {
                DropPanic("Wrong ID");
                return false;
            }
            if (RunCommand.AddContainerToWarehouse(idCont)) return true;
            DropPanic("Something goes wrong");
            return false;
        }

        /// <summary>
        /// Calls one of the container creation functions
        /// depending on the user's choice
        /// </summary>
        /// <returns></returns>
        private static Container CreateNewContainer()
        {
            Screen.PrintMessage(new Dictionary<string, string>()
            {
                {"1. Пустой контейнер", "Message"},
                {"2. Контейнер с коробками", "Message"},
            });
            switch (Console.ReadLine())
            {
               case "1":
                   return CreateEmptyContainer();
               case "2":
                   return CreateContainerWithBoxes();
               default:
                   DropPanic("Неверный выбор");
                   break;
            }
            return null;
        }
        
        /// <summary>
        /// Reads information about the contents of
        /// a new container and calls the function to create it
        /// </summary>
        /// <returns></returns>
        private static Container CreateContainerWithBoxes()
        {
            var newContainer = RunCommand.CreateEmptyContainer();
            Screen.PrintMessage(new Dictionary<string, string>()
            {
                {"Пустой контейнер успешно создан, вот иноформация о нём", "Message"},
                {newContainer.ToString(), "InfoAbout"},
            });
            Screen.PrintMessage(new Dictionary<string, string>()
            {
                {"Сколько ящиков вы хотите создать?", "Message"}
            });
            if (!int.TryParse(Console.ReadLine(), out var n) || n <= 0)
            {
                DropPanic("Неверное число коробок");
                return null;
            }
            Box newBox;
            for (var i = 0; i < n; i++)
            {
                newBox = CreateNewBox();
                if(newBox!=null)
                    RunCommand.AddBoxToContainer(newBox.GetId(), newContainer.GetId());
            }
            Screen.PrintMessage(new Dictionary<string, string>()
            {
                {"Контейнер успешно наполнен коробками, вот иноформация о нём", "Message"},
                {newContainer.ToString(), "InfoAbout"},
            });
            return newContainer;
        }
        
        /// <summary>
        /// Сalls the function to create an empty container
        /// </summary>
        /// <returns></returns>
        private static Container CreateEmptyContainer()
        {
            var newContainer = RunCommand.CreateEmptyContainer();
            Screen.PrintMessage(new Dictionary<string, string>()
            {
                {"Пустой контейнер успешно создан и помещен в виртульное хранилище\n Информация о нём:", "Message"},
                {newContainer.ToString(), "InfoAbout"},
                {
                    "В любой момент его можно переместить на склад или же увидеть его в " +
                    "списке виртуального хранилища",
                    "Message"
                },
            });
            return newContainer;
        }
        
        /// <summary>
        /// Reads information about a new box and creates it,
        /// adding it to VirtualWarehouse
        /// </summary>
        /// <returns></returns>
        private static Box CreateNewBox()
        {
            var questionPrice = new Dictionary<string, string>() {{"Введи цену за кг", "Message"}};
            Screen.PrintMessage(questionPrice);
            if (!double.TryParse(Console.ReadLine(), out var price) || price <= 0)
            {
                DropPanic("Неверная цена за кг");
                return null;
            }
            var questionWeight = new Dictionary<string, string>() {{"Введи вес коробки", "Message"}};
            Screen.PrintMessage(questionWeight);
            if (!double.TryParse(Console.ReadLine(), out var weight) || weight <= 0)
            {
                DropPanic("Неверный Вес");
                return null;
            }

            var newBox = RunCommand.CreateNewBox(price, weight);
            if (newBox == null)
            {
                DropPanic("Коробка не создана");
                return null;
            }
            Screen.PrintMessage(new Dictionary<string, string>()
                {
                    {"Коробка успешно создана\nИнформация о ней", "Message"},
                    { newBox.ToString(), "InfoAbout"},
                });
            return newBox;
        }
        
        /// <summary>
        /// Reads the ID of the container and the box and calls the function to add the box to the container
        /// </summary>
        /// <returns></returns>
        private static bool AddBoxToContainer()
        {
            Screen.PrintMessage(new Dictionary<string, string>() {{"Введи ID Коробки", "Message"}});
            if (!int.TryParse(Console.ReadLine(), out var idBox))
            {
                DropPanic("Wrong ID");
                return false;
            }
            Screen.PrintMessage(new Dictionary<string, string>() {{"Введи ID Контейнера", "Message"}});
            if (!int.TryParse(Console.ReadLine(), out var idCont))
            {
                DropPanic("Wrong ID");
                return false;
            }
            return RunCommand.AddBoxToContainer(idBox, idCont);
        }
        /// <summary>
        /// Reads the container and box IDs and calls the function to remove the box from the container
        /// </summary>
        /// <returns></returns>
        private static bool RemoveBoxFromContainer()
        {
            Screen.PrintMessage(new Dictionary<string, string>() {{"Введи ID Коробки", "Message"}});
            if (!int.TryParse(Console.ReadLine(), out var idBox))
            {
                DropPanic("Wrong ID");
                return false;
            }
            Screen.PrintMessage(new Dictionary<string, string>() {{"Введи ID Контейнера", "Message"}});
            if (!int.TryParse(Console.ReadLine(), out var idCont))
            {
                DropPanic("Wrong ID");
                return false;
            } 
            return RunCommand.RemoveBoxFromContainer(idBox, idCont);
        }
        /// <summary>
        /// Reads the container ID and calls the function to remove the container from the warehouse
        /// </summary>
        /// <returns></returns>
        private static bool RemoveContainerFromWarehouse()
        {
            Screen.PrintMessage(new Dictionary<string, string>() {{"Введи ID Контейнера", "Message"}});
            if (int.TryParse(Console.ReadLine(), out var idCont))
                return RunCommand.RemoveContainerFromWarehouse(idCont);
            DropPanic("Wrong ID");
            return false;
        }
        
        /// <summary>
        /// Reads the container id and calls the function Display information about it
        /// </summary>
        private static void LookForContainer()
        {
            Screen.PrintMessage(new Dictionary<string, string>()
            {
                {"Введите ID контейнера", "Message"}
            });
            if (!int.TryParse(Console.ReadLine(), out var id) || id <= 0)
            {
                DropPanic("Неверный ID");
                return;
            }
            Screen.PrintMessage(new Dictionary<string, string>()
            {
                {RunCommand.LookForContainer(id), "InfoAbout"}
            });
        }
        
        /// <summary>
        /// Reads the box id and calls the function Display information about it
        /// </summary>
        private static void LookForBox()
        {
            Screen.PrintMessage(new Dictionary<string, string>()
            {
                {"Введите ID коробки", "Message"}
            });
            if (!int.TryParse(Console.ReadLine(), out var id) || id <= 0)
            {
                DropPanic("Неверный ID");
                return;
            }
            Screen.PrintMessage(new Dictionary<string, string>()
            {
                {RunCommand.LookForBox(id), "InfoAbout"}
            });
        }
        /// <summary>
        /// displays information about all boxes in VirtualWarehouse
        /// </summary>
        private static void LookForBoxesInVirtualWarehouse()
        {
            Screen.PrintBoxArray(RunCommand.LookForBoxesInVirtualWarehouse());
        }
        
        /// <summary>
        /// displays information about all containers in VirtualWarehouse
        /// </summary>
        private static void LookForContainersInVirtualWarehouse()
        {
            Screen.PrintContainerArray(RunCommand.LookForContainersInVirtualWarehouse());
        }
    }
}