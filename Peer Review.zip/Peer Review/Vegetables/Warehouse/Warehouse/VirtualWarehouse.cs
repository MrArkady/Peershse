using System.Collections.Generic;
using System.Linq;

namespace Warehouse
{
    /// <summary>
    /// A helper class that contains boxes and containers
    /// that could not be placed in their storage
    /// </summary>
    public static class VirtualWarehouse
    {
        //List of containers not placed in the warehouse
        public static List<Box> _boxes = new List<Box>();
        //List of boxes not placed in a container
        public static List<Container> _containers = new List<Container>();
        //Next available box ID
        private static int _boxId = 0;
        //Next available Container ID
        private static int _containerId = 0;
        //Next available Warehouse ID(doesn't used)
        private static int _warehouseId = 1;
        
        public static int LastBoxId => _boxId;
        public static int ContainerId => _containerId;
        public static Container FirstContainer => _containers[0];

        public static int WarehouseId => _warehouseId++;

        /// <summary>
        /// Adding a new box to virtual storage
        /// and issuing a new ID to it
        /// </summary>
        /// <param name="newBox">New Box</param>
        /// <returns>Box ID</returns>
        public static int AddNewBoxToVirtualWarehouse(Box newBox)
        {
            _boxes.Add(newBox);
            _boxId += 1;
            return _boxId;
        }

        /// <summary>
        /// Adding a new box to virtual storage
        /// </summary>
        /// <param name="newBox">New box</param>
        /// <returns>done or not</returns>
        public static bool AddBoxToVirtualWarehouse(Box newBox)
        {
            if (FindBox(newBox.GetId()) != null) return false;
            _boxes.Add(newBox);
            return true;
        }
        
        /// <summary>
        /// Adding a new container to virtual storage
        /// </summary>
        /// <param name="newContainer">New Container</param>
        /// <returns>done or not</returns>
        public static bool AddContainerToVirtualWarehouse(Container newContainer)
        {
            if (FindContainer(newContainer.GetId()) != null) return false;
            _containers.Add(newContainer);
            return true;
        }
        
        /// <summary>
        /// Removes container from Virtual Warehouse
        /// </summary>
        /// <param name="newBox">Box to remove</param>
        /// <returns>Done or not</returns>
        public static bool RemoveBoxFromVirtualWarehouse(Box newBox)
        {
            if (!_boxes.Contains(newBox)) return false;
            _boxes.Remove(newBox);
            return true;
        }

        /// <summary>
        /// Adding a new Container to virtual storage
        /// and issuing a new ID to it
        /// </summary>
        /// <returns>Container ID</returns>
        public static int AddNewContainerToVirtualWarehouse(Container newContainer)
        {
            _containers.Add(newContainer);
            _containerId += 1;
            return _containerId;
        }

        /// <summary>
        /// Removes container from Virtual Warehouse
        /// </summary>
        /// <param name="newContainer">Container to remove</param>
        /// <returns>Done or not</returns>
        public static bool RemoveContainerFromVirtualWarehouse(Container newContainer)
        {
            if (!_containers.Contains(newContainer)) return false;
            _containers.Remove(newContainer);
            return true;
        }
        
        /// <summary>
        /// looking for a container in a Virtual Warehouse by id
        /// </summary>
        /// <param name="id" type="int">Container id</param>
        /// <returns>Returns an object of class Container by id</returns>
        public static Container FindContainer(int id)
        {
            return _containers.Find(x => x.GetId() == id);
        }
        
        /// <summary>
        /// looking for a box in a Virtual Warehouse by id
        /// </summary>
        /// <param name="id" type="int">box id</param>
        /// <returns>Returns an object of class box by id</returns>
        public static Box FindBox(int id)
        {
            return _boxes.Find(x => x.GetId() == id);
        }
        
        /*
        public static string MakeStringOfBoxes()
        {
            return _boxes.Aggregate(string.Empty, (current, box) => current + box + "\n");
        }
        public static string MakeStringOfContainers()
        {
            return _containers.Aggregate(string.Empty,
                (current, container) => current + (container + "\n"));
        }
        */
    }
}