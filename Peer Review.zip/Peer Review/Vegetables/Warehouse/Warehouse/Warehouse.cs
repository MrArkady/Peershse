using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;


namespace Warehouse
{
    /// <summary>
    /// Class that implements the warehouse
    /// </summary>
    public class Warehouse
    {
        // Personal Warehouse ID
        private readonly int _warehoseId;
        private readonly List<Container> _containers = new List<Container>();
        private readonly double _maxCount;
        private readonly double _cost;
        
        private double NowCount => this._containers.Count;
        private double SumCost => NowCount * this._cost;

        /// <summary>
        /// Warehouse constructor
        /// </summary>
        /// <param name="maxCount">Maximum number of containers in the warehouse</param>
        /// <param name="cost">Storage price</param>
        public Warehouse(double maxCount, double cost)
        {
            this._warehoseId = VirtualWarehouse.WarehouseId;
            this._maxCount = maxCount;
            this._cost = cost;
        }

        /// <summary>
        /// Adding a Container to a Warehouse
        /// </summary>
        /// <remarks>If the Count of containers after adding a new one
        /// exceeds the maximum number of the containers in the warehouse, then the container is not added</remarks>
        /// <remarks>If the Container is already present in the warehouse, then it is not added to it</remarks>
        /// <remarks>If the Container is not in the Virtual Storage, then it is not added</remarks>
        /// <param name="container"></param>
        /// <returns>Added or not</returns>
        public bool AddToWarehouse(Container container)
        {
            if (container.СostLostWithDamage <= this._cost) return false;
            if (this.NowCount >= this._maxCount)
            {
                if (!VirtualWarehouse.RemoveContainerFromVirtualWarehouse(container)) return false;
                if (this._containers.Contains(container)) return false;
                for (var i = 0; i < this._maxCount-1; i++)
                {
                    this._containers[i] = this._containers[i + 1];
                }
                this._containers.Remove(_containers.Last());
                this._containers.Add(container);
                return true;
            }
            if (!VirtualWarehouse.RemoveContainerFromVirtualWarehouse(container)) return false;
            if (this._containers.Contains(container)) return false;
            this._containers.Add(container);
            return true;
        }
        
        /// <summary>
        /// removes the container from the warehouse and moves it to Virtual Warehouse
        /// </summary>
        /// <param name="container">container</param>
        /// <returns>Done or not</returns>
        public bool RemoveContainerFromWarehouse(Container container)
        {
            if (!_containers.Contains(container)) return false;
            _containers.Remove(container);
            VirtualWarehouse.AddContainerToVirtualWarehouse(container);
            return true;
        }
        
        /// <summary>
        /// looking for a container in a Warehouse by id
        /// </summary>
        /// <param name="id" type="int">Container id</param>
        /// <returns>Returns an object of class Container by id</returns>
        public Container FindContainer(int id)
        {
            return _containers.Find(x => x.GetId() == id);
        }

        /// <summary>
        /// looking for a box in a Warehouse by id
        /// </summary>
        /// <param name="id" type="int">box id</param>
        /// <returns>Returns an object of class box by id</returns>
        public Box FindBoxInContainers(int id)
        {
            return _containers.Select(container => container.FindBox(id)).FirstOrDefault(newBox => newBox != null);
        }
        

        /// <summary>
        /// Generating a line with information about a warehouse
        /// </summary>
        /// <returns> String with information</returns>
        public override string ToString()
        {
            var res = $"|\tid: {this._warehoseId}\t|\tMax: {this._maxCount}\t|\tNow In: {this.NowCount}\t|\tSumm Cost: {SumCost}\n";
            foreach (var container in this._containers)
            {
                res += "\t" + container + Environment.NewLine;
            }
            return res;
        }
    }
}