using System;
using System.Collections.Generic;
using System.Reflection.Metadata.Ecma335;
using System.Runtime.InteropServices;

namespace Bulls_And_Cows
{
    /// <summary>
    /// The Digit class is responsible for the correct random generation of a number of the required length,
    /// calculation of cows and bulls
    /// </summary>
    /// <value>digit_ - the number itself</value>
    /// <value><list type="int">digit_content_- the composition of the number - its numbers</list></value>
    /// <value>length_ - Number length</value>
    public class GameDigit
    {
        
        private uint digit_;
        private List<int> digit_content_;
        private uint length_;
        
        /// <summary>
        /// class constructor, creates a put list for storing the digits of a number,
        /// calls the method for generating a number of a given length
        /// </summary>
        /// <param name="settings">Game settings - the length of the number is taken from here</param>
        /// 
        public GameDigit(GameSettings settings)
        {
            this.digit_content_ = new List<int>();
            this.length_ = settings.Getlength();
            this.digit_ = this.CreateDigit();
        }
        /// <summary>
        /// Digit Length
        /// </summary>
        /// <returns>Length of the digit</returns>
        public uint GetLength() => this.length_;
        
        /// <summary>
        /// Get Numeral by index
        /// </summary>
        /// <param name="i">required digit index</param>
        /// <returns>the desired digit of the number</returns>
        public int GetNumeral(int i) => this.digit_content_[i];
        
        /// <summary>
        /// List of all numbers
        /// </summary>
        /// <returns>List of all numbers of digit</returns>
        public List<int> GetAllNumerals() => this.digit_content_;
        
        
        
        
        /// <summary>
        /// generates a random digit from 0 to 9 that has not yet been in the number.
        /// Adds it to digit content
        /// </summary>
        /// <param name="rand">Random object</param>
        /// <returns>random unique number</returns>
        private int GenerateRandDigit(System.Random rand)
        {
            int digit;
            do
            {
                digit = rand.Next(10);
            } while (this.digit_content_.Contains(digit));

            return digit;
        }
        /// <summary>
        /// converts a list of digits to a number
        /// </summary>
        /// <param name="list"></param>
        /// <returns>Number collected by digits</returns>
        /// <exception cref="Exception">Error while converting list to integer oin class digit</exception>
        private static uint ListToDigit(List<int> list)
        {
            uint digit;
            string str = String.Join("", list);
            if (!uint.TryParse(str, out digit))
            {
                throw new Exception("Error while converting list to integer oin class digit");
            }

            return digit;
        }
        /// <summary>
        /// A method for generating a random number with unique digits.
        /// The first digit is a random digit from 1 to 9,
        /// then a loop for the length of the number, which calls the GenerateRandDigit method
        /// </summary>
        /// <returns>Generated number</returns>
        private uint CreateDigit()
        {
            var rand = new System.Random();
            this.digit_content_.Add(rand.Next(9)+1); // first digit rand.Next(10)+1
            for (int i = 1; i < this.length_; i++)
            {
                this.digit_content_.Add(this.GenerateRandDigit(rand));
            }
            return ListToDigit(this.digit_content_);
        }
        
        /// <summary>
        /// converts a number to a list of digits
        /// </summary>
        /// <param name="digit">number</param>
        /// <returns>list of digits of a number</returns>
        /// <exception cref="Exception">Error while converting Digit to list of integers oin class digit</exception>
        private List<int> DigitToList(uint digit)
        {
            string str_numb = digit.ToString();
            List<int> str_list = new List<int>();
            
            foreach (char _ch in str_numb)
            {
                if (_ch >= '0' && _ch <= '9')
                    str_list.Add(_ch - '0');
                else
                {
                    throw new Exception("Error while converting Digit to list of integers oin class digit");
                }
            }
            return str_list;
        }
        
        /// <summary>
        /// Compares the number entered by the user and the hidden number,
        /// counts the number of bulls and cows
        /// </summary>
        /// <param name="user_digit">user entered number</param>
        /// <returns>Dictionary
        /// ["bulls"] - the number of bulls
        /// ["cows"] - number of cows</returns>
        public Dictionary<string, uint> CheckUserDigit(uint user_digit)
        {
            Dictionary<string, uint> res = new Dictionary<string, uint>();
            res.Add("cows", 0);
            res.Add("bulls", 0);
            
            List<int> user_digit_str = this.DigitToList(user_digit);

            for (int i = 0; i < user_digit_str.Count; i++)
            {
                if (this.GetNumeral(i).Equals(user_digit_str[i]))
                {
                    res["bulls"] += 1;
                }
                else
                {
                    res["cows"] += this.GetAllNumerals().Contains(user_digit_str[i]) ? 1U : 0U;
                }
            }
            return res;
        }
        
        /// <summary>
        /// Number information
        /// </summary>
        /// <returns>A line with basic information about the number</returns>
        public string GetInfo()
        {
            return ($"\n Digit: \t {this.digit_} \n " +
                    $"Его цифры: \t {String.Join(" ",this.digit_content_)} \n " +
                    $"Его Длинна: \t {this.length_}");
        }
    }
}