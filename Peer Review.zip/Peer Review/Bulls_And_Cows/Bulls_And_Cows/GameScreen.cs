using System;
using System.Collections.Generic;

namespace Bulls_And_Cows
{
    /// <summary>
    /// User interaction class
    /// </summary>
    public class GameScreen
    {
        /// <summary>
        /// When creating a class, a method is called to display an informational message
        /// </summary>
        public GameScreen()
        {
            this.StartGameMessage();
        }
        
        /// <summary>
        /// Displays a message and waits for the user's response
        /// </summary>
        /// <param name="UserInfo">The message to display to the user</param>
        /// <returns>User response string</returns>
        public string GetAnswer(string UserInfo, GameStatus status)
        {
            Console.Clear();
            ShowStatus(status, UserInfo);
            string answer = Console.ReadLine();
            return answer;
        }
        
        /// <summary>
        /// Displaying game status, game information
        /// </summary>
        /// <param name="status">GameStatus class object storing current information about the game</param>
        public void ShowStatus(GameStatus status, string UserMessage = "")
        {
            Dictionary<string, uint> round = status.GetRoundInfo();
            Console.Clear();
            string game_name = "Быки и Коровы",
                wins = "Побед: " + status.CountOfWinnings().ToString(),
                defeats = "Поражений: " + status.CountOfDefeats().ToString(),
                number_of_round = "Номер раунда: " + status.NumberOfRound().ToString(),
                attempt = "Попытка номер: " + round["attempt"].ToString(),
                bulls_count = "Количество быков: " + round["bulls_count"].ToString(),
                cows_count = "Колличество коров " + round["cows_count"].ToString(),
                max_attempt = "Всего попыток: " + round["max_attempt"].ToString(),
                border = "_________________________________________";
            
            string FormatString = $"{game_name}\n" +
                                  $"\t {defeats} \n \t {wins} \n {border} \n{number_of_round} \n {max_attempt}\n" +
                                  $"{attempt}\n" +
                                  $"{border}\n" +
                                  $"{border}\n" +
                                  $"{bulls_count}\n" +
                                  $"{cows_count}\n" +
                                  $"{border}\n{border}\n" +
                                  $"{UserMessage}\n";
            Console.Write(FormatString);
        }
        
        /// <summary>
        /// Welcome message to the user
        /// </summary>
        public void StartGameMessage()
        {
            string start_message = " \t \t \t \t \t Тебя приветствует игра Быки и Коровы!";
            Console.Clear();
            Console.Write(start_message);
            Console.ReadLine();
        }
    }
}