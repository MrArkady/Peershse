﻿using System;

namespace Bulls_And_Cows
{
    class Program
    {
        static void Main(string[] args)
        {
            GameSession game = new GameSession();
        }
    }
}