using System;
using System.Collections.Generic;

namespace Bulls_And_Cows
{
    public class GameRound
    {
        private uint bulls_count_;
        private uint cows_count_;
        private uint attempt_number_;
        private GameDigit digit_;
        private uint max_attempt_;
        private GameStatus _status;

        public GameRound(int maxAttempt, GameSettings settings, GameStatus status)
        {
            max_attempt_ = maxAttempt==-1?0U:(uint)maxAttempt;
            bulls_count_ = 0;
            cows_count_ = 0;
            attempt_number_ = 0;
            digit_ = new GameDigit(settings);
            _status = status;
        }
        
        public uint CountOfBulls() => this.bulls_count_;
        public uint CountOfCows() => this.cows_count_;
        public uint AttemptNumber() => this.attempt_number_;
        public Dictionary<string, uint> GetRoundInfo()
        {
            Dictionary<string, uint> info = new Dictionary<string, uint>();
            info.Add("attempt", this.attempt_number_);
            info.Add("bulls_count", this.bulls_count_);
            info.Add("cows_count", this.cows_count_);
            info.Add("max_attempt", max_attempt_);
            return info;
        }
        
        private bool IsUniq(uint res)
        {
            int[] uniq_digit = new int[10];
            string res_str = res.ToString();
            
            for (int i = 0; i < 10; i++)
            {
                uniq_digit[i] = 0;
            }
            for (int i = 0; i < res_str.Length; i++)
            {
                uniq_digit[res_str[i] - '0']++;
            }

            for (int i = 0; i < res_str.Length; i++)
            {
                if (uniq_digit[i] > 1)
                {
                    return false;
                }
            }

            return true;
        }
        
        public uint CheckUserDigit(uint DigitLength, GameScreen screen)
        {
            uint res;
            do
            {
                this.attempt_number_++;
                screen.ShowStatus(_status, $"Попытайтесь угадать число! (введите число длинны {DigitLength} такое,\n " +
                                           $"чтобы каждая цифра этого числа была унильной");
            } while ((!uint.TryParse(Console.ReadLine(), out res)) ||
                     res.ToString().Length != DigitLength);
            return res;
        }
        
        
        
        /// <summary>
        /// Function Started the round
        /// </summary>
        /// <param name="screen">screen to push text</param>
        public void StartRound(GameScreen screen)
        {
            uint answer_int;
            //Console.WriteLine(digit_.GetInfo());
            if (this.max_attempt_ == 0)
            {
                while (this.bulls_count_ != digit_.GetLength())
                {
                    
                    answer_int = CheckUserDigit(digit_.GetLength(), screen);
                    Dictionary<string, uint> bullsAndCows = digit_.CheckUserDigit(answer_int);
                    this.bulls_count_ = bullsAndCows["bulls"];
                    this.cows_count_ = bullsAndCows["cows"];
                }

                this.WinRound();
            }
        }
        
        public void WinRound()
        {
            Console.Clear();
            Console.WriteLine("Вы ВЫИГРАЛИ!");
        }
        
        public void DefeatRound()
        {
            // Start Output Function
            
        }
        
    }
}



