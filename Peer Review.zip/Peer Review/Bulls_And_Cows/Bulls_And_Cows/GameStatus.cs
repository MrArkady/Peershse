using System;
using System.Collections.Generic;

namespace Bulls_And_Cows
{
    /// <summary>
    /// Class containing basic information about the game
    /// </summary>
    /// <list type="GameRound">List consisting of all rounds of the current game</list>
    /// <code>count_of_defeats - Number of defeats in the current game session</code>
    /// <code>round_number - current round number</code>
    public class GameStatus
    {
        public List<GameRound> rounds;
        private uint count_of_defeats;
        private uint round_number;
        /// <summary>
        /// Structure constructor
        /// </summary>
        /// <param name="roundNumber"></param>
        public GameStatus(uint RoundNumber = 0)
        {
            this.rounds = new List<GameRound>();
            this.count_of_defeats = 0;
            this.round_number = RoundNumber;
        }

        public void EndRound(bool result)
        {
            this.count_of_defeats += result ? 0U : 1U; // true - win; false - lose
        }
        
        /// <summary>
        /// Creates a new round of the game
        /// </summary>
        /// <param name="result">Roseltat of the current round</param>
        /// <param name="settings">new round settings</param>
        public void NextRound(GameSettings settings, GameScreen screen)
        {
            this.round_number += 1;
            //this.rounds = new List<GameRound>();
            GameRound new_round = new GameRound(settings.GetNumberOfAttempts(), settings, this);
            this.rounds.Add(new_round);
            new_round.StartRound(screen);
            this.EndRound(true);
        }

        /// <summary>
        /// Number of wins
        /// </summary>
        /// <returns>Number of wins</returns>
        public uint CountOfWinnings() => this.round_number - 1 - this.count_of_defeats;
        
        
        /// <summary>
        /// Number of defeats
        /// </summary>
        /// <returns>Number of defeats</returns>
        public uint CountOfDefeats() => this.count_of_defeats;
        
        /// <summary>
        /// Current round number
        /// </summary>
        /// <returns>Current round number</returns>
        public uint NumberOfRound() => this.round_number;
        
        /// <summary>
        /// object of the current round
        /// </summary>
        /// <returns>Returns the object of the current round</returns>
        public GameRound GetNowRound() => this.rounds[(int)this.round_number-1];
        
        /// <summary>
        /// Information on the current round
        /// </summary>
        /// <returns>A string with information about the current round</returns>
        public Dictionary<string, uint> GetRoundInfo() => this.GetNowRound().GetRoundInfo();
        
    }
}