using System;
using System.Collections.Generic;

namespace Bulls_And_Cows
{
    public struct GameSettings
    {
        private uint digit_length;
        private int number_of_attempts;
        
        public GameSettings(uint digitLength = 4, int numberOfAttempts = -1)
        {
            digit_length = digitLength;
            number_of_attempts = numberOfAttempts;
        }

        public void SetLength(uint length)
        {
            this.digit_length = length;
        }
        
        public uint Getlength() => this.digit_length;
        public int GetNumberOfAttempts() => this.number_of_attempts;

        public string GetInfo()
        {
            string att = this.number_of_attempts == -1 ? "не ограничено" : this.number_of_attempts.ToString();
            return $"Длинна числа для загадывания - {this.Getlength()} \n количество попыток - {att}";
        }
    }
}