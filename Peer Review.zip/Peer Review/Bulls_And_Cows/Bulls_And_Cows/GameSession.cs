using System;
using System.Collections.Generic;

namespace Bulls_And_Cows
{
    public class GameSession
    {
        private GameSettings game_settings_;
        private GameStatus game_status_;
        private GameScreen game_screen_;

        public GameSession()
        {
            game_screen_ = new GameScreen();
            game_settings_ = new GameSettings(4, -1);
            game_status_ = new GameStatus();
            this.StartSession();
        }


        private string TakeUserAnswer(string message, List<string> possibleAnswers)
        {
            string user_answer;
            do
            {
                Console.WriteLine(message);
                user_answer = Console.ReadLine();
            } while (!possibleAnswers.Contains(user_answer));
            
            return user_answer;
        }
        
        private void AskForChangeSettings()
        {
            string user_answer, message = $"Сейчас установлены следующие нстройки \n" +
                             $" {game_settings_.GetInfo()} \n Хотите их длинну числа? " +
                             $"(yes/no)";
            
            user_answer = this.TakeUserAnswer(message, new List<string>(){"yes", "no"});

            if (user_answer == "yes")
            {
                uint new_length;
                user_answer = this.TakeUserAnswer("Введите длинну числа от 1 до 9",
                    new List<string>() {"1", "2", "3", "4", "5", "6", "7", "8", "9"});
                uint.TryParse(user_answer, out new_length);
                game_settings_.SetLength(new_length); q
            }
        }


        public void StartSession()
        {
            string user_answer;
            game_screen_.StartGameMessage();
            user_answer = this.TakeUserAnswer("ГОТОВЫ НАЧАТЬ??", new List<string>() {"yes", "no"});
            if (user_answer == "yes")
            {
                this.StartGame();
            }

            return;
        }
        
        public void StartGame()
        {
            do
            {
                this.AskForChangeSettings();
                game_status_.NextRound(game_settings_, game_screen_);
            } while (this.TakeUserAnswer("Хотите еще раз?", new List<string>() {"yes", "no"}) != "no");
        }
    }
}