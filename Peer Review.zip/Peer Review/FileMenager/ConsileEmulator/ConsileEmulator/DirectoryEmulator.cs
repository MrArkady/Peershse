using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;

namespace ConsileEmulator
{
    public class DirectoryEmulator
    {
        private DirectoryInfo nowDirectory;
        private string nowPath;
        
        // Constructor
        public DirectoryEmulator(string nowDirectoryPath)
        {
            this.nowDirectory = new DirectoryInfo(nowDirectoryPath);
            this.nowPath = this.nowDirectory.FullName;
        }

        private static string PathParser(string path, string nowpath)
        {
            var nowPathList = nowpath.Split(new char[] {Path.DirectorySeparatorChar}).ToList();
            foreach (var i in path.Split(new char[]{Path.DirectorySeparatorChar}))
            {
                if (i == "..")
                    nowPathList.RemoveAt(nowPathList.Count-1);
                else if (i!=".")
                    nowPathList.Add(i);
            }
            return Path.DirectorySeparatorChar + Path.Combine(nowPathList.ToArray());
        }
        
        public string ChangeDirectory(string path)
        {
            if (path.Length <= 1)
                return "No Such Path, check for correct inputs";
            if (path[0] == Path.DirectorySeparatorChar)
            {
                if (new DirectoryInfo(path).Exists)
                {
                    var safeDir = nowDirectory;
                    try
                    {
                        nowDirectory = new DirectoryInfo(path);
                    }
                    catch (Exception e)
                    {
                        nowDirectory = safeDir;
                        return e.Message;
                    }
                    nowPath = path;
                    return "ok";
                }
                return "No Such Directory";
            }
            var newPath = PathParser(path, nowPath);
            if (new DirectoryInfo(newPath).Exists)
            {
                var safeDir = nowDirectory;
                try
                {
                    nowDirectory = new DirectoryInfo(newPath);
                }
                catch (Exception e)
                {
                    nowDirectory = safeDir;
                    return e.Message;
                }
                nowPath = newPath;
                return "ok";
            }
            return "No Such Directory";
        }
        
        public string ConcatenationFiles(string[] paths)
        {
            var result = string.Empty;
            foreach (var iPath in paths)
            {
                try
                {
                    if (IsFile(iPath) == "file")
                    {
                        result += File.ReadAllText(PathParser(iPath, nowPath));
                    }
                }
                catch (Exception e)
                {
                    return e.Message;
                }
            }
            try
            {
                CommandClasses.CreateFile.RunCommand(this, paths.Last(), result);
                return "ok";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }
        public string CreateDirectory(string name)
        {
            try
            {
                var newPath = PathParser(name, nowPath);
                Directory.CreateDirectory(newPath);
                return "ok";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }
        public string CreateFile(string path, string text)
        {
            try
            {
                var newPath = PathParser(path, nowPath);
                ScreenManager.OutputMessage(new Dictionary<string, string>()
                {
                    {"Choose in which frame to create the file(UTF-8/UTF-7/UTF-32)", "exception"}
                });
                switch (Console.ReadLine())
                {
                    case "UTF-8":
                        File.WriteAllText(newPath, text, Encoding.UTF8);
                        return "ok";
                    case "UTF-7":
                        File.WriteAllText(newPath, text, Encoding.UTF7);
                        return "ok";
                    case "UTF-32":
                        File.WriteAllText(newPath, text, Encoding.UTF32);
                        return "ok";
                    default:
                        return "Wrong Frame Selected\nTry again";
                }
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }
        public string DeleteFileOrDirectory(string path)
        {
            path = PathParser(path, nowPath);
            switch (IsFile(path))
            {
                case "nothing":
                    return "Wrong Path";
                case "folder":
                    try
                    {
                        ScreenManager.OutputMessage(new Dictionary<string, string>()
                        {
                            {"Are you sure?(yes/no)", "exception"}
                        });
                        if (Console.ReadLine() == "yes")
                        {
                            var folder = new DirectoryInfo(path);
                            folder.Delete(true);
                            return "ok";
                        }
                        else
                            return "ok";
                    }
                    catch (Exception e)
                    {
                        return e.Message;
                    }
                case "file":
                    try
                    {
                        ScreenManager.OutputMessage(new Dictionary<string, string>()
                        {
                            {"Are you sure?(yes/no)", "exception"}
                        });
                        if (Console.ReadLine() == "yes")
                        {
                            var file = new FileInfo(path);
                            file.Delete();
                            return "ok";
                        }
                        else
                            return "ok";
                    }
                    catch (Exception e)
                    {
                        return e.Message;
                    }
                default:
                    return "smth went wrong";
            }
        }
        public Dictionary<string, string> LookSource()
        {
            try
            {
                var result = new Dictionary<string, string>();
                foreach (var info in this.nowDirectory.GetDirectories())
                { 
                    result.Add(info.Name, "folder");
                }
                foreach (var info in this.nowDirectory.GetFiles())
                { 
                    result.Add(info.Name, "file");
                }

                return result;
            }
            catch (Exception e)
            {
                return new Dictionary<string, string>(){{e.Message, "exception"}};
            }
        }

        private static string IsFile(string path)
        {
            if (File.Exists(path))
                return "file";
            if (Directory.Exists(path))
                return "folder";
            return "nothing";
        }
        
        public string Move(string from, string to)
        {
            if (from.Length <= 1 | to.Length <= 1)
                return "No Such Path, check for correct inputs";
            
            from = PathParser(from, nowPath);
            to = PathParser(to, nowPath);
            
            if (IsFile(from) == "nothing")
            {
                return "Wrong from path";
            }
            // if (IsFile(from) != IsFile(to)) 
            //     return "paths must be the same type (folders or files)";
            //
            switch (IsFile(from))
            {
                case "file":
                    try
                    {
                        var file = new FileInfo(from);
                        file.MoveTo(to);
                    }
                    catch (Exception e)
                    {
                        return e.Message;
                    }
                    break;
                case "folder":
                    try
                    {
                        var folder = new DirectoryInfo(from);
                        folder.MoveTo(to);
                    }
                    catch (Exception e)
                    {
                        return e.Message;
                    }
                    break;
                default:
                    return "mistake while moving";
            }
            return "ok";
        }
        public string ShowFile(string path)
        {
            if (path.Length <= 1)
                return "No Such Path, check for correct inputs";
            path = PathParser(path, nowPath);
            switch (IsFile(path))
            {
                case "file":
                    try
                    {
                        ScreenManager.OutputMessage(new Dictionary<string, string>()
                        {
                            {"Choose in which frame to read the file(UTF-8/UTF-7/UTF-32)", "exception"}
                        });
                        switch (Console.ReadLine())
                        {
                            case "UTF-8":
                                ScreenManager.OutputMessage(new Dictionary<string, string>()
                                {
                                    {File.ReadAllText(path, Encoding.UTF8), "file"}
                                });
                                return "ok";
                            case "UTF-7":
                                ScreenManager.OutputMessage(new Dictionary<string, string>()
                                {
                                    {File.ReadAllText(path, Encoding.UTF7), "file"}
                                });
                                return "ok";
                            case "UTF-32":
                                ScreenManager.OutputMessage(new Dictionary<string, string>()
                                {
                                    {File.ReadAllText(path, Encoding.UTF32), "file"}
                                });
                                return "ok";
                            default:
                                return "Wrong Frame Selected\nTry again";
                        }
                    }
                    catch (Exception e)
                    {
                        return e.Message;
                    }
                default:
                    return "Something goes wrong while reading file";
            }
        }
        public string ShowNowPath => nowPath;

        public string CopyFile(string fileName)
        {
            var fileNamePath = PathParser(fileName, nowPath);
            if (IsFile(fileNamePath)=="file")
            {
                try
                {
                    File.Copy(fileNamePath,  PathParser("copy-"+fileName, nowPath));
                    return "ok";
                }
                catch (Exception e)
                {
                    return e.Message;
                }
            }

            Console.WriteLine(fileNamePath);
            
            return "Try Again, wrong file";
        }

        public string ChangeDisk()
        {
            var drivers = Environment.GetLogicalDrives();
            
            var d = new Dictionary<string, string>();
            d.Add("Write Number of disk", "exception");
            for (int i = 0; i < drivers.Length; i++)
            {
                d.Add(i.ToString() + drivers[i], "folder");
            }
            ScreenManager.OutputMessage(d);
            try
            {
                Directory.SetCurrentDirectory(drivers[int.Parse(Console.ReadLine())]);
                this.nowDirectory = new DirectoryInfo(Directory.GetCurrentDirectory());
                this.nowPath = this.nowDirectory.FullName;
                return "ok";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }
    }
}