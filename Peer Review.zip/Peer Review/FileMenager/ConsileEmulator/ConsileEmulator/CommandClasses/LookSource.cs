using System.Collections.Generic;

namespace ConsileEmulator.CommandClasses
{
    public class LookSource
    {
        /// <summary>
        /// prints exception
        /// </summary>
        /// <param name="exception">Exception message</param>
        public static void PrintException(string Exception)
        {
            var ex = new Dictionary<string, string> {{Exception, "exception"}};
            ScreenManager.OutputMessage(ex);
        }
        /// <summary>
        /// PRINTS ALL IN THE DIRECTORY
        /// </summary>
        /// <param name="sources">all files and directories</param>
        public static void PrintAllSource(Dictionary<string,string> sources)
        {
            ScreenManager.OutputMessage(sources);
        }
        /// <summary>
        /// Calls Change Directory
        /// </summary>
        /// <param name="emulator">Now Emulator class</param>
        public static void RunCommand(DirectoryEmulator emulator)
        {
            var sources = emulator.LookSource();
            PrintAllSource(sources);
        }
        
    }
}