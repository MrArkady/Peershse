using System.Collections.Generic;

namespace ConsileEmulator.CommandClasses
{
    public class ChangeDisk
    {
        /// <summary>
        /// prints exception
        /// </summary>
        /// <param name="exception">Exception message</param>
        public static void PrintException(string exception)
        {
            var ex = new Dictionary<string, string>
            {
                {exception, "exception"}
            };
            ScreenManager.OutputMessage(ex);
        }
        /// <summary>
        /// Calls Change Disk Function
        /// </summary>
        /// <param name="e">Now Emulator</param>
        public static void RunCommand(DirectoryEmulator e)
        {
            string commandException = e.ChangeDisk();
            if (commandException != "ok")
            {
                PrintException(commandException);
            }
        }
    }
}