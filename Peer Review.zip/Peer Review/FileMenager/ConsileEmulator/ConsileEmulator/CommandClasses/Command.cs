using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;

namespace ConsileEmulator.CommandClasses
{
    public class Command
    {

        public static readonly List<string> possibleCommands = new List<string>()
        {
            "cd", "mv", "con", "rm", "ls", "cat", "mkdir", "touch", "exit", "clear", "copy", "chdisk", "help"
        };

        public static string PathParse(string path)
        {
            return Regex.Unescape(@path);
        }
        
        
        private static void CallCdCommand(string[] command, DirectoryEmulator emulator)
        {
            if (command[0] == "cd" && command.Length == 2)
                ChangeDirectory.RunCommand(emulator, command[1]);
            else
                ScreenManager.OutputMessage(new Dictionary<string, string>(){
                    {"Wrong Arguments in cd command", "exception"}
            });
        }
        
        private static void CallMvCommand(string[] command, DirectoryEmulator emulator)
        {
            if (command.Length == 3 && command[0] == "mv")
                Move.RunCommand(emulator, command[1], command[2]);
            else
            {
                ScreenManager.OutputMessage(new Dictionary<string, string>(){
                    {"Wrong Arguments in mv command", "exception"}
                });
            }
        }
        private static void CallConCommand(string[] command, DirectoryEmulator emulator)
        {
            var list_commands = new List<string>();
            if (command.Length >= 3 && command[0] == "con")
            {
                for (int i = 1; i < command.Length; i++)
                {
                    list_commands.Add(command[i]);
                }
                ConcatenationFiles.RunCommand(emulator, list_commands.ToArray());
            }
            else
            {
                ScreenManager.OutputMessage(new Dictionary<string, string>(){
                    {"Wrong Arguments in mv command", "exception"}
                });
            }
        }
        private static void CallRmCommand(string[] command, DirectoryEmulator emulator)
        {
            if (command[0] == "rm" && command.Length == 2)
                DeleteFileOrDirectory.RunCommand(emulator, command[1]);
            else
                ScreenManager.OutputMessage(new Dictionary<string, string>(){
                    {"Wrong Arguments in cd command", "exception"}
                });
        }
        private static void CallLsCommand(string[] command, DirectoryEmulator emulator)
        {
            if (command.Length == 1 && command[0] == "ls")
                LookSource.RunCommand(emulator);
            else
            {
                ScreenManager.OutputMessage(new Dictionary<string, string>(){
                    {"Wrong Arguments in ls command", "exception"}
                });
            }
        }
        private static void CallCatCommand(string[] command, DirectoryEmulator emulator)
        {
            if (command.Length == 2 && command[0] == "cat")
                ShowFile.RunCommand(emulator, command[1]);
            else
            {
                ScreenManager.OutputMessage(new Dictionary<string, string>()
                {
                    {"Wrong Arguments in cat command", "exception"}
                });
            }
        }
        private static void CallMkDirCommand(string[] command, DirectoryEmulator emulator)
        {
            if (command.Length == 2 && command[0] == "mkdir")
                CreateDirectory.RunCommand(emulator, command[1]);
            else
            {
                ScreenManager.OutputMessage(new Dictionary<string, string>()
                {
                    {"Wrong Arguments in mkdir command", "exception"}
                });
            }
        }
        private static void CallTouchCommand(string[] command, DirectoryEmulator emulator)
        {
            if (command.Length == 3 && command[0] == "touch")
                CreateFile.RunCommand(emulator, command[1], command[2]);
            else
            {
                ScreenManager.OutputMessage(new Dictionary<string, string>()
                {
                    {"Wrong Arguments in mkdir command", "exception"}
                });
            }
        }
        
        private static void CallCopyCommand(string[] command, DirectoryEmulator emulator)
        {
            if (command.Length == 2 && command[0] == "copy")
            {
                CopyFile.RunCommand(emulator, command[1]);
            }
            else
            {
                ScreenManager.OutputMessage(new Dictionary<string, string>()
                {
                    {"Wrong Arguments in copy command", "exception"}
                });
            }
        }
        
        private static void CallSelectDiskCommand(string[] command, DirectoryEmulator emulator)
        {
            if (command.Length == 1 && command[0] == "chdisk")
                ChangeDisk.RunCommand(emulator);
            else
            {
                ScreenManager.OutputMessage(new Dictionary<string, string>(){
                    {"Wrong Arguments in ls command", "exception"}
                });
            }
        }

        public static bool ParseCommand(string[] command, DirectoryEmulator emulator)
        {
            if (command.Length < 1 | !(possibleCommands.Contains(command[0])))
            {
                ScreenManager.OutputMessage(new Dictionary<string, string>(){
                    {"Wrong Command", "exception"}
                });
            }else
                switch (command[0])
                {
                    case "exit":
                        return false;
                    case "cd":
                        CallCdCommand(command, emulator); 
                        break;
                    case "mv":
                        CallMvCommand(command, emulator);
                        break;
                    case "clear":
                        ScreenManager.CleanScreen(); 
                        break;
                    case "con":
                        CallConCommand(command, emulator);
                    break;
                    case "rm":
                        CallRmCommand(command, emulator);
                    break;
                    case "ls":
                        CallLsCommand(command, emulator);
                    break;
                    case "cat":
                        CallCatCommand(command, emulator);
                    break;
                    case "mkdir":
                        CallMkDirCommand(command, emulator);
                    break;
                    case "touch":
                        CallTouchCommand(command, emulator);
                    break;
                    case "help":
                        ScreenManager.OutputHelp();
                    break;
                    case "copy":
                        CallCopyCommand(command, emulator);
                    break;
                    case "chdisk":
                        CallSelectDiskCommand(command, emulator);
                    break;
                }
            return true;
        }
    }
}