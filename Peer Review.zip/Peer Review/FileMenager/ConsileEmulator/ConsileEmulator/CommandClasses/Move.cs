using System.Collections.Generic;

namespace ConsileEmulator.CommandClasses
{
    public class Move
    {
        /// <summary>
        /// prints exception
        /// </summary>
        /// <param name="exception">Exception message</param>
        public static void PrintException(string Exception)
        {
            var ex = new Dictionary<string, string> {{Exception, "exception"}};
            ScreenManager.OutputMessage(ex);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="emulator"></param>
        /// <param name="From"></param>
        /// <param name="To"></param>
        public static void RunCommand(DirectoryEmulator emulator, string From, string To)
        {
            string commandException = emulator.Move(From, To);
            if (commandException != "ok")
            {
                PrintException(commandException);
            }
            
        }
    }
}