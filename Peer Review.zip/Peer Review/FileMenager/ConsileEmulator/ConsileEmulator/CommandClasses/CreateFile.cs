using System.Collections.Generic;

namespace ConsileEmulator.CommandClasses
{
    public class CreateFile
    {
        /// <summary>
        /// prints exception
        /// </summary>
        /// <param name="exception">Exception message</param>
        public static void PrintException(string exception)
        {
            var ex = new Dictionary<string, string> {{exception, "exception"}};
            ScreenManager.OutputMessage(ex);
        }
        /// <summary>
        /// Calls Change Directory
        /// </summary>
        /// <param name="e">Now Emulator class</param>
        /// <param name="path">file name</param>
        /// <param name="text">file text</param>
        public static void RunCommand(DirectoryEmulator emulator, string path, string text)
        {
            string commandException = emulator.CreateFile(path, text);
            if (commandException != "ok")
            {
                PrintException(commandException);
            }
        }
    }
}