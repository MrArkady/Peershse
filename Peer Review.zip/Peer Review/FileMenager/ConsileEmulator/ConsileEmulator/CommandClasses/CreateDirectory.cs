using System.Collections.Generic;

namespace ConsileEmulator.CommandClasses
{
    public class CreateDirectory
    {
        /// <summary>
        /// prints exception
        /// </summary>
        /// <param name="exception">Exception message</param>
        public static void PrintException(string exception)
        {
            var ex = new Dictionary<string, string> {{exception, "exception"}};
            ScreenManager.OutputMessage(ex);
        }
        /// <summary>
        /// Calls Change Directory
        /// </summary>
        /// <param name="e">Now Emulator class</param>
        /// <param name="path">directory name</param>
        public static void RunCommand(DirectoryEmulator emulator, string path)
        {
            string commandException = emulator.CreateDirectory(path);
            if (commandException != "ok")
            {
                PrintException(commandException);
            }
        }
    }
}