using System.Collections.Generic;

namespace ConsileEmulator.CommandClasses
{
    public class CopyFile
    {
        /// <summary>
        /// prints exception
        /// </summary>
        /// <param name="exception">Exception message</param>
        public static void PrintException(string exception)
        {
            var ex = new Dictionary<string, string> {{exception, "exception"}};
            ScreenManager.OutputMessage(ex);
        }
        /// <summary>
        /// Calls Change Directory
        /// </summary>
        /// <param name="e">Now Emulator class</param>
        /// <param name="goToPath">file name</param>
        public static void RunCommand(DirectoryEmulator e, string goToPath)
        {
            string commandException = e.CopyFile(goToPath);
            if (commandException != "ok")
            {
                PrintException(commandException);
            }
        }
    }
}