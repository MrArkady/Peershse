using System.Collections.Generic;

namespace ConsileEmulator.CommandClasses
{
    public class ShowFile
    {
        /// <summary>
        /// prints exception
        /// </summary>
        /// <param name="exception">Exception message</param>
        public static void PrintException(string exception)
        {
            var ex = new Dictionary<string, string> {{exception, "exception"}};
            ScreenManager.OutputMessage(ex);
        }
        public static void RunCommand(DirectoryEmulator emulator, string path)
        {
            string commandException = emulator.ShowFile(path);
            if (commandException != "ok")
            {
                PrintException(commandException);
            }
        }
    }
}