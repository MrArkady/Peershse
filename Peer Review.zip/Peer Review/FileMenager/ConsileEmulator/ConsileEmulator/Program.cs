﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection.PortableExecutable;

namespace ConsileEmulator
{
    static class Program
    {
        static void Main(string[] args)
        {
            var Emulator = new DirectoryEmulator(Environment.CurrentDirectory);
            // //ScreenManager.OutputHelp();
            // ScreenManager.OutputInput(Emulator);
            ScreenManager.StartEmulator(Emulator);
        }
    }
}