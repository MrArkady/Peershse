using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Channels;
using ConsileEmulator.CommandClasses;

namespace ConsileEmulator
{
    public class ScreenManager
    {

        public static void OutputHelp()
        {
            string help = File.ReadAllText("help.txt");
            Console.WriteLine(help);
        }

        public static void CleanScreen()
        {
            Console.Clear();
        }
        public static bool OutputInput(DirectoryEmulator nowDirectory)
        {
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write(nowDirectory.ShowNowPath + " $ ");
            Console.ResetColor();
            return InputCommand(nowDirectory);
        }
        
        /// <summary>
        /// Prints Message with type color  
        /// </summary>
        /// <param name="message">Dirctionary of message and type possible
        /// types - exception, folder, file</param>
        /// <exception cref="Exception">If Type is wrong</exception>
        public static void OutputMessage(Dictionary<string, string> message)
        {
            foreach (var i in message)
            {
                switch (i.Value)
                {
                    // Output Color = RED
                    case "exception":
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine(i.Key);
                        Console.ResetColor();
                        break;
                    // Output Color = Green
                    case "folder":
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(i.Key);
                        Console.ResetColor();
                        break;
                    // Output Color = Blue
                    case "file":
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.WriteLine(i.Key);
                        Console.ResetColor();
                        break;
                    default:
                        throw new Exception("Wrong Type When Output");
                }
            }
        }

        public static bool InputCommand(DirectoryEmulator nowDirectory)
        {
            try
            {
                var command = Console.ReadLine().Split(new char[]{' '});
                for (int i = 0; i < command.Length; i++)
                {
                    command[i] = Command.PathParse(command[i]);
                }
                return Command.ParseCommand(command, nowDirectory);
                
            }
            catch (Exception e)
            {
                ScreenManager.OutputMessage(new Dictionary<string, string>(){{e.Message, "exception"}});
                return true;
            }
        }

        public static void StartEmulator(DirectoryEmulator nowDirectory)
        {
            while (OutputInput(nowDirectory))
            {
                
            }
        }
    }         
}             